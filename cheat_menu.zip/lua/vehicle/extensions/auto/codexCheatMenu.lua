local M = {}
M.dependencies = {"core_quickAccess"}

local abs = math.abs
local floor = math.floor
local max = math.max
local min = math.min

local CHEAT_ROOT = "/root/playerVehicle/cheats/"
local CHEAT_POWER_ROOT = CHEAT_ROOT .. "power/"
local POWER_PRESETS = {1, 1.5, 2, 3, 5, 10, 50, 100}
local PS_TO_WATT = 735.499
local RPM_TO_AV = math.pi / 30
local INVULNERABLE_BEAM_LIMIT = 1e20
local SUPER_GRIP_MULTIPLIER = 4.5
local LOW_GRAVITY_FACTOR = 0.35
local HIGH_SPEED_MIN_RPM = 26000
local HIGH_SPEED_MAX_RPM = 60000

local state = {
  invulnerable = false,
  powerMultiplier = 1,
  superGrip = false,
  lowGravity = false
}

local menuRegistered = false
local pendingReapplyFrames = 0
local needsPowerBaseRefresh = true
local powerBaseData = {}
local wheelGripBaseData = {}
local wheelBurstBaseData = {}
local transmissionBaseData = {}
local gravityBaseValue = nil
local vehicleControllerBaseData = {
  captured = false,
  topSpeedLimit = nil,
  topSpeedLimitReverse = nil
}
local originalGuihooksMessage = nil

local function hasActiveCheat()
  return state.invulnerable
    or abs(state.powerMultiplier - 1) > 0.001
    or state.superGrip
    or state.lowGravity
end

local function showStatusMessage(message, id)
  guihooks.message(message, 4, id or "codexCheatMenu")
end

local function scheduleReapply(frameCount)
  pendingReapplyFrames = max(pendingReapplyFrames, frameCount or 2)
end

local function setupMessageHook()
  if not originalGuihooksMessage and guihooks and type(guihooks.message) == "function" then
    originalGuihooksMessage = guihooks.message
    guihooks.message = function(msg, time, category, icon)
      if state.powerMultiplier > 1.001 or state.invulnerable then
        local catStr = type(category) == "string" and category:lower() or ""
        local msgStr = type(msg) == "string" and msg:lower() or ""

        local isDamageMsg = catStr:find("damage") or catStr:find("engine")
          or msgStr:find("грм") or msgStr:find("оборотами") or msgStr:find("радиатор")
          or msgStr:find("двигател") or msgStr:find("engine") or msgStr:find("valvetrain")
          or msgStr:find("radiator") or msgStr:find("oil") or msgStr:find("coolant")
          or msgStr:find("поврежден") or msgStr:find("перегрев")

        if isDamageMsg then
          return 
        end
      end
      return originalGuihooksMessage(msg, time, category, icon)
    end
  end
end

local function getNumericCurveMaxRPM(curve)
  local curveMaxRPM = 0
  for key, _ in pairs(curve or {}) do
    local numericKey = type(key) == "number" and key or tonumber(key)
    if numericKey then
      curveMaxRPM = max(curveMaxRPM, numericKey)
    end
  end
  return floor(curveMaxRPM)
end

local function capturePowerBaseData()
  powerBaseData = {}

  local engineDevices = powertrain.getDevicesByCategory and powertrain.getDevicesByCategory("engine") or {}
  for _, device in ipairs(engineDevices) do
    local curveMaxRPM = getNumericCurveMaxRPM(device.torqueCurve)
    powerBaseData[device.name] = {
      torqueCurve = deepcopy(device.torqueCurve or {}),
      maxTorqueRating = device.maxTorqueRating,
      maxRPM = device.maxRPM,
      maxAV = device.maxAV,
      maxAvailableRPM = device.maxAvailableRPM,
      maxSoundRPM = device.maxSoundRPM,
      revLimiterRPM = device.revLimiterRPM,
      revLimiterAV = device.revLimiterAV,
      revLimiterMaxAV = device.revLimiterMaxAV,
      invRevLimiterRange = device.invRevLimiterRange,
      revLimiterMaxAVOvershoot = device.revLimiterMaxAVOvershoot,
      hasRevLimiter = device.hasRevLimiter,
      revLimiterType = device.revLimiterType,
      redlineTorqueDropOffRange = device.redlineTorqueDropOffRange,
      curveMaxRPM = curveMaxRPM
    }
  end

  needsPowerBaseRefresh = false
end

local function refreshDevicePerformanceData(device)
  if not device.getTorqueData then
    return
  end

  device.torqueData = device:getTorqueData()
  device.maxPower = device.torqueData.maxPower
  device.maxTorque = device.torqueData.maxTorque

  if device.maxPowerThrottleMap ~= nil then
    device.maxPowerThrottleMap = device.torqueData.maxPower * PS_TO_WATT
  end

  if device.idleRPM ~= nil then
    device.idleTorque = device.torqueCurve[floor(device.idleRPM or 0)] or device.idleTorque or 0
  end

  if device.resetTempRevLimiter then
    device:resetTempRevLimiter()
  end
end

local function restoreEngineDevice(device, baseData)
  device.torqueCurve = deepcopy(baseData.torqueCurve or {})
  device.maxTorqueRating = baseData.maxTorqueRating
  device.maxRPM = baseData.maxRPM
  device.maxAV = baseData.maxAV
  device.maxAvailableRPM = baseData.maxAvailableRPM
  device.maxSoundRPM = baseData.maxSoundRPM
  device.revLimiterRPM = baseData.revLimiterRPM
  device.revLimiterAV = baseData.revLimiterAV
  device.revLimiterMaxAV = baseData.revLimiterMaxAV
  device.invRevLimiterRange = baseData.invRevLimiterRange
  device.revLimiterMaxAVOvershoot = baseData.revLimiterMaxAVOvershoot
  device.hasRevLimiter = baseData.hasRevLimiter
  device.revLimiterType = baseData.revLimiterType
  device.redlineTorqueDropOffRange = baseData.redlineTorqueDropOffRange
  refreshDevicePerformanceData(device)
end

local function getTargetMaxRPM(baseData)
  local baseRPM = max(
    baseData.revLimiterRPM or 0,
    baseData.maxRPM or 0,
    baseData.maxAvailableRPM or 0,
    baseData.curveMaxRPM or 0
  )

  if state.powerMultiplier <= 1.001 then
    return baseRPM
  end

  local scaledTargetRPM = baseRPM * (1 + (state.powerMultiplier - 1) * 1.35)
  return floor(min(max(scaledTargetRPM, HIGH_SPEED_MIN_RPM), HIGH_SPEED_MAX_RPM))
end

local function buildScaledTorqueCurve(baseData, targetMaxRPM)
  local scaledCurve = {}
  local baseCurve = baseData.torqueCurve or {}

  local maxStockTorque = 0
  for key, value in pairs(baseCurve) do
    if type(value) == "number" then
      scaledCurve[key] = value * state.powerMultiplier
      if value > maxStockTorque then
        maxStockTorque = value
      end
    else
      scaledCurve[key] = deepcopy(value)
    end
  end

  local curveMaxRPM = baseData.curveMaxRPM or 0
  if targetMaxRPM <= curveMaxRPM or curveMaxRPM <= 0 then
    return scaledCurve
  end

  local extensionTorque = maxStockTorque * state.powerMultiplier

  for rpm = curveMaxRPM + 1, targetMaxRPM do
    scaledCurve[rpm] = extensionTorque
  end

  return scaledCurve
end

local function applyVehicleControllerSpeedOverride(enabled)
  local vehicleController = controller and controller.getController and controller.getController("vehicleController")
  if not vehicleController then
    return false
  end

  if not vehicleControllerBaseData.captured then
    vehicleControllerBaseData.topSpeedLimit = vehicleController.topSpeedLimit
    vehicleControllerBaseData.topSpeedLimitReverse = vehicleController.topSpeedLimitReverse
    vehicleControllerBaseData.captured = true
  end

  local targetForward = enabled and 9999 or vehicleControllerBaseData.topSpeedLimit
  local targetReverse = enabled and 9999 or vehicleControllerBaseData.topSpeedLimitReverse

  vehicleController.topSpeedLimit = targetForward
  vehicleController.topSpeedLimitReverse = targetReverse

  return true
end

local function applyTireBurstFix(enabled)
  if next(wheelBurstBaseData) == nil then
    for i, wheel in pairs(wheels.wheels or {}) do
      wheelBurstBaseData[i] = wheel.tireBurstAV or 99999
    end
  end

  for i, wheel in pairs(wheels.wheels or {}) do
    if enabled then
      wheel.tireBurstAV = math.huge
    else
      wheel.tireBurstAV = wheelBurstBaseData[i]
    end
  end
end

local function applyTransmissionFix(enabled)
  if not powertrain or type(powertrain.getDevices) ~= "function" then return end
  
  if next(transmissionBaseData) == nil then
    for name, device in pairs(powertrain.getDevices()) do
      transmissionBaseData[name] = {
        clutchTorque = device.clutchTorque,
        baseClutchTorque = device.baseClutchTorque,
        lockTorque = device.lockTorque,
        maxTorqueRating = device.maxTorqueRating
      }
    end
  end

  for name, device in pairs(powertrain.getDevices()) do
    local base = transmissionBaseData[name]
    if base then
      if enabled then
        local multi = max(state.powerMultiplier, 10)
        if device.clutchTorque and base.clutchTorque then device.clutchTorque = base.clutchTorque * multi end
        if device.baseClutchTorque and base.baseClutchTorque then device.baseClutchTorque = base.baseClutchTorque * multi end
        if device.lockTorque and base.lockTorque then device.lockTorque = base.lockTorque * multi end
        device.maxTorqueRating = math.huge
      else
        if device.clutchTorque then device.clutchTorque = base.clutchTorque end
        if device.baseClutchTorque then device.baseClutchTorque = base.baseClutchTorque end
        if device.lockTorque then device.lockTorque = base.lockTorque end
        device.maxTorqueRating = base.maxTorqueRating
      end
    end
  end
end

local function applyPowerMultiplier()
  local engineDevices = powertrain.getDevicesByCategory and powertrain.getDevicesByCategory("engine") or {}
  local highSpeedMode = state.powerMultiplier > 1.001

  applyVehicleControllerSpeedOverride(highSpeedMode)
  applyTireBurstFix(highSpeedMode)
  applyTransmissionFix(highSpeedMode)

  if #engineDevices == 0 then
    return false
  end

  if needsPowerBaseRefresh or next(powerBaseData) == nil then
    capturePowerBaseData()
  end

  for _, device in ipairs(engineDevices) do
    local baseData = powerBaseData[device.name]
    if not baseData then
      needsPowerBaseRefresh = true
      capturePowerBaseData()
      baseData = powerBaseData[device.name]
    end

    if baseData then
      if state.powerMultiplier <= 1.001 then
        restoreEngineDevice(device, baseData)
      else
        local targetMaxRPM = getTargetMaxRPM(baseData)
        device.torqueCurve = buildScaledTorqueCurve(baseData, targetMaxRPM)

        device.maxTorqueRating = math.huge

        device.maxAvailableRPM = max(baseData.maxAvailableRPM or 0, targetMaxRPM)
        device.maxRPM = targetMaxRPM
        device.maxAV = targetMaxRPM * RPM_TO_AV

        if device.maxSoundRPM ~= nil then
          device.maxSoundRPM = targetMaxRPM
        end

        if baseData.hasRevLimiter then
          device.hasRevLimiter = true
          device.revLimiterRPM = targetMaxRPM
          device.revLimiterAV = device.maxAV

          if baseData.revLimiterType == "soft" then
            local overshoot = baseData.revLimiterMaxAVOvershoot or (50 * RPM_TO_AV)
            device.revLimiterMaxAV = device.maxAV + overshoot
            device.invRevLimiterRange = 1 / max(device.revLimiterMaxAV - device.maxAV, 1e-30)
          else
            device.revLimiterMaxAV = baseData.revLimiterMaxAV
            device.invRevLimiterRange = baseData.invRevLimiterRange
          end
        end

        refreshDevicePerformanceData(device)
      end
    end
  end

  if powertrain.sendTorqueData then
    powertrain.sendTorqueData()
  end

  return true
end

local function captureWheelGripBaseData()
  wheelGripBaseData = {}

  for _, wheel in pairs(wheels.wheels or {}) do
    local wheelNodes = wheel.treadNodes or wheel.nodes or {}
    for _, nodeCID in ipairs(wheelNodes) do
      local nodeData = v and v.data and v.data.nodes and v.data.nodes[nodeCID]
      if nodeData and not wheelGripBaseData[nodeCID] then
        local friction = nodeData.frictionCoef or 1
        local slidingFriction = nodeData.slidingFrictionCoef or friction
        wheelGripBaseData[nodeCID] = {
          friction = friction,
          slidingFriction = slidingFriction
        }
      end
    end
  end
end

local function applySuperGrip()
  if next(wheelGripBaseData) == nil then
    captureWheelGripBaseData()
  end

  for nodeCID, baseData in pairs(wheelGripBaseData) do
    local friction = state.superGrip and baseData.friction * SUPER_GRIP_MULTIPLIER or baseData.friction
    local slidingFriction = state.superGrip and baseData.slidingFriction * SUPER_GRIP_MULTIPLIER or baseData.slidingFriction
    obj:setNodeFrictionSlidingCoefs(nodeCID, friction, slidingFriction)
  end
end

local function applyLowGravity()
  if gravityBaseValue == nil then
    gravityBaseValue = obj:getGravity()
  end

  local targetGravity = state.lowGravity and (gravityBaseValue * LOW_GRAVITY_FACTOR) or gravityBaseValue
  obj:setGravity(targetGravity)
end

local function applyInvulnerability()
  if not v or not v.data or not v.data.beams then
    return
  end

  for _, beam in pairs(v.data.beams) do
    if beam and beam.cid ~= nil then
      if state.invulnerable then
        obj:setBeamStrength(beam.cid, INVULNERABLE_BEAM_LIMIT)
        obj:setBeamDeform(beam.cid, INVULNERABLE_BEAM_LIMIT)
      else
        obj:setBeamStrength(beam.cid, beam.beamStrength or math.huge)
        obj:setBeamDeform(beam.cid, beam.beamDeform or math.huge)
      end
    end
  end
end

local function applyCheatState()
  applyInvulnerability()
  local powerApplied = applyPowerMultiplier()
  applySuperGrip()
  applyLowGravity()
  return powerApplied
end

local function healDrivetrain()
  local engineDevices = powertrain.getDevicesByCategory and powertrain.getDevicesByCategory("engine") or {}
  for _, device in ipairs(engineDevices) do
    device.isBroken = false
    device.valvetrainDamage = 0
    device.engineBlockDamage = 0
    device.oilPanDamage = 0
    device.rodBearingsDamaged = false
    device.headGasketBlown = false
    device.pistonRingsDamaged = false
    device.catastrophicFailure = false
    device.wearFrictionPenalty = 0
    device.damage = 0
    device.wear = 0

    if device.thermals then
      device.thermals.valvetrainDamage = 0
      device.thermals.engineBlockDamage = 0
      if device.thermals.coolantTemperature then
        device.thermals.coolantTemperature = min(device.thermals.coolantTemperature, 100)
      end
      if device.thermals.oilTemperature then
        device.thermals.oilTemperature = min(device.thermals.oilTemperature, 110)
      end
      if device.thermals.exhaustTemperature then
        device.thermals.exhaustTemperature = min(device.thermals.exhaustTemperature, 800)
      end
    end
  end

  local clutches = powertrain.getDevicesByCategory and powertrain.getDevicesByCategory("clutch") or {}
  for _, device in ipairs(clutches) do
    device.isBroken = false
    device.damage = 0
    if device.thermals and device.thermals.clutchTemperature then
      device.thermals.clutchTemperature = min(device.thermals.clutchTemperature, 150)
    end
  end
end

local function toggleInvulnerability()
  state.invulnerable = not state.invulnerable
  applyInvulnerability()
  showStatusMessage("Cheat Menu: indestructible " .. (state.invulnerable and "ON" or "OFF"), "codexCheatMenuInvulnerable")
end

local function setPowerMultiplier(multiplier)
  state.powerMultiplier = multiplier

  if applyPowerMultiplier() then
    if abs(multiplier - 1) < 0.001 then
      showStatusMessage("Cheat Menu: engine power reset", "codexCheatMenuPower")
    else
      local presetStr = string.format("%g", multiplier)
      showStatusMessage(string.format("Cheat Menu: engine power x%s + max speed mode", presetStr), "codexCheatMenuPower")
    end
  else
    showStatusMessage("Cheat Menu: no engine device found", "codexCheatMenuPower")
  end
end

local function toggleSuperGrip()
  state.superGrip = not state.superGrip
  applySuperGrip()
  showStatusMessage("Cheat Menu: super grip " .. (state.superGrip and "ON" or "OFF"), "codexCheatMenuGrip")
end

local function toggleLowGravity()
  state.lowGravity = not state.lowGravity
  applyLowGravity()
  showStatusMessage("Cheat Menu: low gravity " .. (state.lowGravity and "ON" or "OFF"), "codexCheatMenuGravity")
end

local function resetCheats()
  state.invulnerable = false
  state.powerMultiplier = 1
  state.superGrip = false
  state.lowGravity = false
  applyCheatState()
  showStatusMessage("Cheat Menu: all cheats reset", "codexCheatMenuReset")
end

local function addRootCategory(entries)
  local entry = {
    title = "Cheat Menu",
    ["goto"] = CHEAT_ROOT,
    icon = "infinity",
    uniqueID = "codexCheatMenuRoot",
    categoryOrder = 30,
    ignoreAsRecentAction = true
  }

  if hasActiveCheat() then
    entry.color = "#ff9d2f"
  end

  table.insert(entries, entry)
end

local function addCheatEntries(entries)
  local invulnerabilityEntry = {
    title = state.invulnerable and "Indestructible: ON" or "Indestructible: OFF",
    desc = state.invulnerable and "Blocks new crash damage" or "Lets the vehicle take damage normally",
    icon = "infinity",
    uniqueID = "codexCheatInvulnerable",
    onSelect = function()
      toggleInvulnerability()
      return {"reload"}
    end
  }

  if state.invulnerable then
    invulnerabilityEntry.color = "#4cff93"
  end
  table.insert(entries, invulnerabilityEntry)

  local powerStr = string.format("%g", state.powerMultiplier)
  local powerEntry = {
    title = string.format("Engine Power: x%s", powerStr),
    desc = "Boosts acceleration and unlocks extreme top speed",
    icon = "engine",
    uniqueID = "codexCheatPowerMenu",
    ["goto"] = CHEAT_POWER_ROOT
  }

  if abs(state.powerMultiplier - 1) > 0.001 then
    powerEntry.color = "#ff7033"
  end
  table.insert(entries, powerEntry)

  local gripEntry = {
    title = state.superGrip and "Super Grip: ON" or "Super Grip: OFF",
    desc = state.superGrip and "Massively increases tire grip and stability" or "Makes the car hold the road much harder",
    icon = "carToWheels",
    uniqueID = "codexCheatSuperGrip",
    onSelect = function()
      toggleSuperGrip()
      return {"reload"}
    end
  }

  if state.superGrip then
    gripEntry.color = "#4cff93"
  end
  table.insert(entries, gripEntry)

  local gravityEntry = {
    title = state.lowGravity and "Low Gravity: ON" or "Low Gravity: OFF",
    desc = state.lowGravity and "Sets gravity to a lighter moon-like value" or "Reduces gravity for jumps and floaty handling",
    icon = "charge",
    uniqueID = "codexCheatLowGravity",
    onSelect = function()
      toggleLowGravity()
      return {"reload"}
    end
  }

  if state.lowGravity then
    gravityEntry.color = "#4cff93"
  end
  table.insert(entries, gravityEntry)

  table.insert(entries, {
    title = "Reset Cheats",
    desc = "Return the current vehicle to stock cheat settings",
    icon = "vehicleFeatures03",
    uniqueID = "codexCheatReset",
    onSelect = function()
      resetCheats()
      return {"reload"}
    end
  })
end

local function addPowerEntries(entries)
  local engineDevices = powertrain.getDevicesByCategory and powertrain.getDevicesByCategory("engine") or {}
  if #engineDevices == 0 then
    table.insert(entries, {
      title = "No engine detected",
      desc = "This vehicle has no engine or motor to boost",
      icon = "vehicleFeatures03",
      uniqueID = "codexCheatNoEngine",
      onSelect = function()
        return {"hide"}
      end
    })
    return
  end

  for _, preset in ipairs(POWER_PRESETS) do
    local presetId = tostring(preset):gsub("%.", "_")
    local presetStr = string.format("%g", preset)
    local entry = {
      title = string.format("Power x%s", presetStr),
      desc = preset == 1 and "Restore stock power" or string.format("Multiply engine output by x%s and unlock max speed", presetStr),
      icon = "engine",
      uniqueID = "codexCheatPowerPreset_" .. presetId,
      onSelect = function()
        setPowerMultiplier(preset)
        return {"reload"}
      end
    }

    if abs(state.powerMultiplier - preset) < 0.001 then
      entry.color = "#4cff93"
    end

    table.insert(entries, entry)
  end
end

local function registerQuickAccessMenu()
  if menuRegistered then
    return
  end

  if not extensions or not extensions.core_quickAccess or not extensions.core_quickAccess.addEntry then
    log("E", "codexCheatMenu", "core_quickAccess is not available; cheat menu registration skipped")
    return
  end

  menuRegistered = true
  log("I", "codexCheatMenu", "Registering cheat menu entries")

  extensions.core_quickAccess.addEntry({
    level = "/root/playerVehicle/",
    generator = addRootCategory
  })

  extensions.core_quickAccess.addEntry({
    level = CHEAT_ROOT,
    generator = addCheatEntries
  })

  extensions.core_quickAccess.addEntry({
    level = CHEAT_POWER_ROOT,
    generator = addPowerEntries
  })
end

local function onExtensionLoaded()
  log("I", "codexCheatMenu", "Vehicle cheat extension loaded")
  setupMessageHook()
  registerQuickAccessMenu()
  needsPowerBaseRefresh = true
end

local function onVehicleLoaded()
  log("D", "codexCheatMenu", "Vehicle loaded, scheduling cheat reapply")
  needsPowerBaseRefresh = true
  powerBaseData = {}
  wheelGripBaseData = {}
  wheelBurstBaseData = {}
  transmissionBaseData = {}
  gravityBaseValue = nil
  vehicleControllerBaseData = {
    captured = false,
    topSpeedLimit = nil,
    topSpeedLimitReverse = nil
  }
  scheduleReapply()
end

local function onReset()
  log("D", "codexCheatMenu", "Vehicle reset, scheduling cheat reapply")
  -- ИСПРАВЛЕНИЕ: Больше не очищаем базовые данные (powerBaseData и т.д.) при нажатии R
  scheduleReapply()
end

local function updateGFX(dt)
  if pendingReapplyFrames > 0 then
    pendingReapplyFrames = pendingReapplyFrames - 1
    if pendingReapplyFrames <= 0 then
      applyCheatState()
    end
  end

  if state.powerMultiplier > 1.001 or state.invulnerable then
    healDrivetrain()
  end
end

M.onExtensionLoaded = onExtensionLoaded
M.onVehicleLoaded = onVehicleLoaded
M.onReset = onReset
M.updateGFX = updateGFX

return M